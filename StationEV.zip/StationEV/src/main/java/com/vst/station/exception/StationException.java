package com.vst.station.exception;

public class StationException extends RuntimeException {
	private static final long serialVersionUID = 215232344516490651L;

	public StationException(String message) {
		super(message);
	}
}
