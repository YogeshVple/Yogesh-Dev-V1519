package com.vst.station;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StationEvApplication {

	public static void main(String[] args) {
		SpringApplication.run(StationEvApplication.class, args);
	}

}
