package com.vst.station;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationEvApplicationTests {

	@Test
	void contextLoads() {
	}

}
